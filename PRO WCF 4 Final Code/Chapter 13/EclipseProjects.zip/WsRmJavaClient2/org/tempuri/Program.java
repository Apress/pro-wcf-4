package org.tempuri;

public class Program {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		FileServiceTest test = new FileServiceTest();
		test.testSayHello();
		}
		catch (Exception ex){
			System.out.println(ex.getMessage());
		}

	}

}
