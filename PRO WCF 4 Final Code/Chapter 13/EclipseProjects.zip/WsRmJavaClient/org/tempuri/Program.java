package org.tempuri;

public class Program {

	/**
	 * @param args
	 */
	public static void main(String[] args)  {
		
		try {
		// TODO Auto-generated method stub
		System.out.println("Hello world");
		
		FileServiceTest obj = new FileServiceTest();
		obj.testGetFile();
		}
		catch (Exception ex){

			System.out.println(ex.getMessage());
		}
		
		

	}

}
